#pragma once

#include <fstream>
#include <vector>
#include <string>

using namespace std;

extern char nidToIdx[300];

void init();

class Vec2i {
public:
  int x, y;
};

template<class T>
struct Mat2 {
public:
  int n, m;
  vector<T> t;

  void resize(int n, int m) {
    this->n = n;
    this->m = m;
    t.resize(n * m);
  }

  T operator[](const Vec2i &v) const {
    return t[n * v.x + v.y];
  }

  T& operator[](const Vec2i &v) {
    return t[n * v.x + v.y];
  }
};

typedef Mat2<int> Mat2i;

class Scoring
{
public:
  static const int mp = 3;
  static const int mn = -4;

  int m[4][4] = {
    { mp, mn, mn, mn },
    { mn, mp, mn, mn },
    { mn, mn, mp, mn },
    { mn, mn, mn, mp }
  };

  int k = 1;
  int b = 4;
};

class Alignment {
public:
  int score;
  vector<Vec2i> matches;

  void output(ostream &is, const string &a, const string &b) const;
};

class AlignmentAlgorithm {
public:
  virtual ~AlignmentAlgorithm() {}

  virtual Alignment align(const string &a, const string &b, const Scoring &sc) = 0;
};

vector<char> encode(const string &a);
