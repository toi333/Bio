#include <algorithm>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>
#include <ctime>

#include <Core.h>
#include <Algorithms/NaiveCubeAlgo.h>
#include <Algorithms/SquareAlgo.h>

using namespace std;

int main()
{
  init();

  ifstream fi("res/streptococcus_references.fasta");
  vector<string> vs;
  string l;
  while (getline(fi, l)) {
    if (l[0] == '>') {
      vs.push_back(string());
    } else {
      vs.back() += l;
    }
  }
  fi.close();

  int cutoff = 10000;
  for (auto &s : vs) {
    s = s.substr(0, cutoff);
  }

  SquareAA algo;
  //NaiveCubeAA algo;
  Scoring sc;

  int start = clock();
  Alignment sol = algo.align(vs[0], vs[1], sc);
  cout << "Run time: " << (float)(clock() - start) / CLOCKS_PER_SEC << endl;

  sol.output(cout, vs[0], vs[1]);

  system("pause");
}